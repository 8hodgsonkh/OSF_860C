var indexSectionsWithContent =
{
  0: "cfkmp",
  1: "c",
  2: "fp",
  3: "kmp"
};

var indexSectionNames =
{
  0: "all",
  1: "functions",
  2: "groups",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Functions",
  2: "Modules",
  3: "Pages"
};

