var modules =
[
    [ "Functions", "group__group__bsp__functions.html", "group__group__bsp__functions" ],
    [ "Pin Mappings", "group__group__bsp__pins.html", null ],
    [ "Pin States", "group__group__bsp__pin__state.html", "group__group__bsp__pin__state" ]
];